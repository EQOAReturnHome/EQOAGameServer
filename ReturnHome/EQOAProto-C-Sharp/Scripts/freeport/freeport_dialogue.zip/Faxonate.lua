function event_say()
diagOptions = {}
    npcDialogue = "I have traveled many moons in search of the legend known as Xylof.  Yet, in all of my time spent, I have yet to find him. playerName if you see him, please tell me right away."
SendDialogue(mySession, npcDialogue, diagOptions)
end