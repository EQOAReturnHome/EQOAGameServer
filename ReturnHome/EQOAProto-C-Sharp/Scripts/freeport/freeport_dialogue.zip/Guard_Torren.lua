function event_say()
diagOptions = {}
    npcDialogue = "I'm on duty. Shove off."
SendDialogue(mySession, npcDialogue, diagOptions)
end