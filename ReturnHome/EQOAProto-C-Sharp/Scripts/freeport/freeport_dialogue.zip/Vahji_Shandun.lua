function event_say()
diagOptions = {}
    npcDialogue = "Have a bet to set?  A friendly duel?  Maybe a grudge to settle between two rivals?  Well step onto this arena and challenge someone to a duel!!"
SendDialogue(mySession, npcDialogue, diagOptions)
end