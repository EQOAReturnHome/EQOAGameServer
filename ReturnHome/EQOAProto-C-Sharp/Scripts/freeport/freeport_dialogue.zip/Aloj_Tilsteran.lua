function event_say()
diagOptions = {}
    npcDialogue = "You'll have to forgive my brother, he can very uptight sometimes.  Don't take anything he says to heart."
SendDialogue(mySession, npcDialogue, diagOptions)
end