function event_say()
diagOptions = {}
    npcDialogue = "If you have nothing to say then please be on your way."
SendDialogue(mySession, npcDialogue, diagOptions)
end