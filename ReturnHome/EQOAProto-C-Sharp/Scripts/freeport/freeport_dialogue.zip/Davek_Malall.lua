function event_say()
diagOptions = {}
    npcDialogue = "Yes, the darkness touches the dagger and sword evenly. Only those truly embraced by the darkness shall know the truth behind life."
SendDialogue(mySession, npcDialogue, diagOptions)
end