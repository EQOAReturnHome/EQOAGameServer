function event_say()
diagOptions = {}
    npcDialogue = "Away with you, vermin."
SendDialogue(mySession, npcDialogue, diagOptions)
end