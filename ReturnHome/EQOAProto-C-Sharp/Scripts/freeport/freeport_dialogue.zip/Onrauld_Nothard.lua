function event_say()
diagOptions = {}
    npcDialogue = "Get out of my sight."
SendDialogue(mySession, npcDialogue, diagOptions)
end