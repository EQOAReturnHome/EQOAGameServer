function event_say()
diagOptions = {}
    npcDialogue = "There's much to be done, and so little time to do it.  You should be on your way."
SendDialogue(mySession, npcDialogue, diagOptions)
end