function event_say()
diagOptions = {}
    npcDialogue = "Get away from me before my blade leaves you eviscerated!"
SendDialogue(mySession, npcDialogue, diagOptions)
end