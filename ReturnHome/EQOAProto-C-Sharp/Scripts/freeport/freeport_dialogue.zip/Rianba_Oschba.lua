function event_say()
diagOptions = {}
    npcDialogue = "Surely playerName, you have something else to do besides bother me. I have too much to do and so little time. Excuse me."
SendDialogue(mySession, npcDialogue, diagOptions)
end