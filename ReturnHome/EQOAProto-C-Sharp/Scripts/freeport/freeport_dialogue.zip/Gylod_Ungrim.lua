function event_say()
diagOptions = {}
    npcDialogue = "Directly south of here is Muniel's Tea Garden. You can reach it by following the road directly behind me."
SendDialogue(mySession, npcDialogue, diagOptions)
end