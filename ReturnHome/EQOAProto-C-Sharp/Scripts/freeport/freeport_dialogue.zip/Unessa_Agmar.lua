function event_say()
diagOptions = {}
    npcDialogue = "Most people know the term nostalgia, but often times we forget the actual meaning of the word. Nostalgia literally means the pain of something old or long forgotten. A wound that never quite healed.. As mortals, we often chase those things we've lost in hopes of receiving them once more.  Have you ever experienced such a feeling?"
SendDialogue(mySession, npcDialogue, diagOptions)
end