function event_say()
diagOptions = {}
    npcDialogue = "I don't know you, and I don't care to."
SendDialogue(mySession, npcDialogue, diagOptions)
end