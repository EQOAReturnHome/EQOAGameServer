function event_say()
diagOptions = {}
    npcDialogue = "I've got my eye on you, playerName."
SendDialogue(mySession, npcDialogue, diagOptions)
end