function event_say()
diagOptions = {}
    npcDialogue = "Whaddaya' want??"
SendDialogue(mySession, npcDialogue, diagOptions)
end