function event_say()
diagOptions = {}
    npcDialogue = "I'm watching you, playerName."
SendDialogue(mySession, npcDialogue, diagOptions)
end