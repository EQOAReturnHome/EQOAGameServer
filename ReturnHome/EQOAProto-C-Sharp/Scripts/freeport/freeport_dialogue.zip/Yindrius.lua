function event_say()
diagOptions = {}
    npcDialogue = "Hail playerName!"
SendDialogue(mySession, npcDialogue, diagOptions)
end