function event_say()
diagOptions = {}
    npcDialogue = "Whaddaya want?? Can't ya see I'm on duty?"
SendDialogue(mySession, npcDialogue, diagOptions)
end