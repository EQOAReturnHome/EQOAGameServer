function event_say()
diagOptions = {}
    npcDialogue = "I'm sorry.  Is there a reason you are bother me?  Leave at once."
SendDialogue(mySession, npcDialogue, diagOptions)
end