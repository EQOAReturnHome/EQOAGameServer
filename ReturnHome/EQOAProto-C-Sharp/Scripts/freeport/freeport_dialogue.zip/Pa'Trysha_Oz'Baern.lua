function event_say()
diagOptions = {}
    npcDialogue = "A pleasure to see you, playerName. I wish I could stay and chat but time is of the essence."
SendDialogue(mySession, npcDialogue, diagOptions)
end