function event_say()
diagOptions = {}
    npcDialogue = "What do you want with me?"
SendDialogue(mySession, npcDialogue, diagOptions)
end