function event_say()
diagOptions = {}
    npcDialogue = "What's that??  Sorry, I don't know you."
SendDialogue(mySession, npcDialogue, diagOptions)
end