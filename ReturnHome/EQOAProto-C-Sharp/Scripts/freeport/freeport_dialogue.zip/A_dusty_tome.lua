function event_say()
diagOptions = {}
    npcDialogue = " "
SendDialogue(mySession, npcDialogue, diagOptions)
end