function event_say()
diagOptions = {}
    npcDialogue = "I'm sorry but you'll have to excuse me.  I'm extremely busy."
SendDialogue(mySession, npcDialogue, diagOptions)
end