function event_say()
diagOptions = {}
    npcDialogue = "Excuse me, but I am in the middle of research and cannot be bothered at this time. Please vacate the premises immediately."
SendDialogue(mySession, npcDialogue, diagOptions)
end