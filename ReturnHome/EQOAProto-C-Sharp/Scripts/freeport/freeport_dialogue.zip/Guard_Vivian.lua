function event_say()
diagOptions = {}
    npcDialogue = "I'm watching these dunes. No deathfist will get past my eyes."
SendDialogue(mySession, npcDialogue, diagOptions)
end