function event_say()
diagOptions = {}
    npcDialogue = "Scholar Narielle is such an inspiration! I hope to be just like her one day."
SendDialogue(mySession, npcDialogue, diagOptions)
end