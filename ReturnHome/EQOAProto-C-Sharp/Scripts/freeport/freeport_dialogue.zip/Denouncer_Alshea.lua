function event_say()
diagOptions = {}
    npcDialogue = "The darkness will overtake us all, playerName.  Only in the absence of light will the truth be revealed and the true power of light can emerge."
SendDialogue(mySession, npcDialogue, diagOptions)
end