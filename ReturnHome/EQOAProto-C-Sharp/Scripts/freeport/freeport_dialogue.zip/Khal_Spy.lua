function event_say()
diagOptions = {}
    npcDialogue = "Away with you, You'll have me spotted, fool."
SendDialogue(mySession, npcDialogue, diagOptions)
end