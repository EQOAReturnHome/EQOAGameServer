function event_say()
diagOptions = {}
    npcDialogue = "I certainly hope you've no intention of causing a commotion."
SendDialogue(mySession, npcDialogue, diagOptions)
end