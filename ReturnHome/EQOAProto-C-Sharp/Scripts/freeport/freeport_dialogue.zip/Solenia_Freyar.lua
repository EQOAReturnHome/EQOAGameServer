function event_say()
diagOptions = {}
    npcDialogue = "Music isn't just a profession, playerName. It's a way of life. It is it's own art, magic and enchantment that we all can understand. Think about it. It is always there surrounding you, wherever you go."
SendDialogue(mySession, npcDialogue, diagOptions)
end