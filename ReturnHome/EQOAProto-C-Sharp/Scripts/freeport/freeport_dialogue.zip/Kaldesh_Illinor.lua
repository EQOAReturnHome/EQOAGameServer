function event_say()
diagOptions = {}
    npcDialogue = "Can a man not have his drink in peace? Please leave me be."
SendDialogue(mySession, npcDialogue, diagOptions)
end