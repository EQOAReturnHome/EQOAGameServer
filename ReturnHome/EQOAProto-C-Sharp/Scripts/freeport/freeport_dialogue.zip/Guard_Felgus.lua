function event_say()
diagOptions = {}
    npcDialogue = "I'd be happy to show you around if only I were off duty, playerName. Safe travels!"
SendDialogue(mySession, npcDialogue, diagOptions)
end