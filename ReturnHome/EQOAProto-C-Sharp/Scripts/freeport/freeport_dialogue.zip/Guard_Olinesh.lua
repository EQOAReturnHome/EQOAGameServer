function event_say()
diagOptions = {}
    npcDialogue = "Can't you see I'm working here?  If the commander see's me chatting, he'll have me stripped of my position.  Away with you!"
SendDialogue(mySession, npcDialogue, diagOptions)
end