function event_say()
diagOptions = {}
    npcDialogue = "Abide by the law, and your corpse won't be thrown from my blade."
SendDialogue(mySession, npcDialogue, diagOptions)
end