function event_say()
diagOptions = {}
    npcDialogue = "Drink guud!!  Tchuy always come here for guud drink."
SendDialogue(mySession, npcDialogue, diagOptions)
end