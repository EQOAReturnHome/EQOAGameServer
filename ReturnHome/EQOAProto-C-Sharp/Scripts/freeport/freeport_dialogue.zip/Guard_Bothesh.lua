function event_say()
diagOptions = {}
    npcDialogue = "Good tidings, citizen."
SendDialogue(mySession, npcDialogue, diagOptions)
end