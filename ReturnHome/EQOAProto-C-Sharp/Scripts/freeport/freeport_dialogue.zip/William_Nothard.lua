function event_say()
diagOptions = {}
    npcDialogue = "I don't have time for idle chatter.  Please be on your way."
SendDialogue(mySession, npcDialogue, diagOptions)
end