function event_say()
diagOptions = {}
    npcDialogue = "Welcome to our little tavern, playerName.  I hope you find everything here well!"
SendDialogue(mySession, npcDialogue, diagOptions)
end