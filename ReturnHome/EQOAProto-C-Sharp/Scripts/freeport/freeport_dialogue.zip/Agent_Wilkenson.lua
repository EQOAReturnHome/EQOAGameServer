function event_say()
diagOptions = {}
    npcDialogue = "I have nothing to say to you."
SendDialogue(mySession, npcDialogue, diagOptions)
end