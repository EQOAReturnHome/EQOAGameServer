function event_say()
diagOptions = {}
    npcDialogue = "Surely, you have something else to do besides bother me, playerName. I have too much to do and so little time.  Excuse me."
SendDialogue(mySession, npcDialogue, diagOptions)
end