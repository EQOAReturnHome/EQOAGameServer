function event_say()
diagOptions = {}
    npcDialogue = "You should spend your time reading, and gaining knowledge. Nothing bothering me."
SendDialogue(mySession, npcDialogue, diagOptions)
end