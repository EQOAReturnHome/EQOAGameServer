function event_say()
diagOptions = {}
    npcDialogue = "I have nothing to say to ye, playerName."
SendDialogue(mySession, npcDialogue, diagOptions)
end