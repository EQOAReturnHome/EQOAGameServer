function event_say()
diagOptions = {}
    npcDialogue = "Oi!  'ave I got som'hin fer you!!"
SendDialogue(mySession, npcDialogue, diagOptions)
end