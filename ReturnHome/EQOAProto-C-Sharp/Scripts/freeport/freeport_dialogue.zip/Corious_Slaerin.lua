function event_say()
diagOptions = {}
    npcDialogue = "Away with you!  I will turn your corpse into a mound of bone and flesh!"
SendDialogue(mySession, npcDialogue, diagOptions)
end