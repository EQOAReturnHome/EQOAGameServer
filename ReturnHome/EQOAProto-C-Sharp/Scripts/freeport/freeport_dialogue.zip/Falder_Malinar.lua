function event_say()
diagOptions = {}
    npcDialogue = "playerName, have you been to the docks, yet?  'tis a beautiful sight, you cannot miss it!"
SendDialogue(mySession, npcDialogue, diagOptions)
end