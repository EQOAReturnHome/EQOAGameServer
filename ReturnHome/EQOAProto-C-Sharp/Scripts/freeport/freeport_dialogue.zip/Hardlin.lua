function event_say()
diagOptions = {}
    npcDialogue = "Greetings, playerName! I hope you find everything here easily."
SendDialogue(mySession, npcDialogue, diagOptions)
end