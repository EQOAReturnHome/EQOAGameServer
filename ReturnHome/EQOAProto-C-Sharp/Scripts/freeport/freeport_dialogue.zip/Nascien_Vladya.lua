function event_say()
diagOptions = {}
    npcDialogue = "Pardon me, but I am busy at the moment.  Away with you."
SendDialogue(mySession, npcDialogue, diagOptions)
end