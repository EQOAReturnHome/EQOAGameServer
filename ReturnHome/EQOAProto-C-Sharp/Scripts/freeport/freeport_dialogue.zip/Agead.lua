function event_say()
diagOptions = {}
    npcDialogue = "I'm sorry but I'm extremely busy. I wish I had more time to offer you.  Safe travels to you, dear."
SendDialogue(mySession, npcDialogue, diagOptions)
end