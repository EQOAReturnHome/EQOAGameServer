function event_say()
diagOptions = {}
    npcDialogue = "Though trained as entertainers, bards are more powerful than they appear. They're one of the most versatile classes, as they can take on many different roles."
SendDialogue(mySession, npcDialogue, diagOptions)
end