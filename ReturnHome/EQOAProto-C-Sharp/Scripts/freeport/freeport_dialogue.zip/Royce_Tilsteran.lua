function event_say()
diagOptions = {}
    npcDialogue = "What do you want?! Get out of here."
SendDialogue(mySession, npcDialogue, diagOptions)
end