function event_say()
diagOptions = {}
    npcDialogue = "The vampires exist among us.  If you ever find yourself infect, come to me.  I just may be able to save your life."
SendDialogue(mySession, npcDialogue, diagOptions)
end