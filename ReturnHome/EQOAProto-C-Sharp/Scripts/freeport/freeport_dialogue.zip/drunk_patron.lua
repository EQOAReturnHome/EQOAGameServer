function event_say()
diagOptions = {}
    npcDialogue = "*hic* You know, I.. I'd love to get.. *hic* a job but.. I.. *hic* am so preoccupied."
SendDialogue(mySession, npcDialogue, diagOptions)
end