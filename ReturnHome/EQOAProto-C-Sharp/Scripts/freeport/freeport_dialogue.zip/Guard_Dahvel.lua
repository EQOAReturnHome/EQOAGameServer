function event_say()
diagOptions = {}
    npcDialogue = "As you were, citizen."
SendDialogue(mySession, npcDialogue, diagOptions)
end