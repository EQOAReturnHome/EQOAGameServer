function event_say()
diagOptions = {}
    npcDialogue = "I haven't the time to be wasted. Out of my way, peasant!"
SendDialogue(mySession, npcDialogue, diagOptions)
end