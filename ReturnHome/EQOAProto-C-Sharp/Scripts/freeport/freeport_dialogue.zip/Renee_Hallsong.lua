function event_say()
diagOptions = {}
    npcDialogue = "Have you come to learn the trade of song, traveler? No? Well, please be on your way then."
SendDialogue(mySession, npcDialogue, diagOptions)
end