function event_say()
diagOptions = {}
    npcDialogue = "Out of my sight worm, I have no use for you."
SendDialogue(mySession, npcDialogue, diagOptions)
end