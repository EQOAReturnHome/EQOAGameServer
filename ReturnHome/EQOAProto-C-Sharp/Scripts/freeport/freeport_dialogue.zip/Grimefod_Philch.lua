function event_say()
diagOptions = {}
    npcDialogue = "Greetings, friend!  If you haven't any business with me then please be on your way."
SendDialogue(mySession, npcDialogue, diagOptions)
end