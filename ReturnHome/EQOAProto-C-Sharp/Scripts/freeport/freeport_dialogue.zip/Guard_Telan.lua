function event_say()
diagOptions = {}
    npcDialogue = "Let this diverse land be invaded. Our enemies shall know pain by the edge of my blade."
SendDialogue(mySession, npcDialogue, diagOptions)
end