function event_say()
diagOptions = {}
    npcDialogue = "What brings you 'round these parts?"
SendDialogue(mySession, npcDialogue, diagOptions)
end