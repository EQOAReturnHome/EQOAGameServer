function event_say()
diagOptions = {}
    npcDialogue = "Countless times, I have watched the sun set on this town, and I often wonder.. when will be my final sunset?"
SendDialogue(mySession, npcDialogue, diagOptions)
end