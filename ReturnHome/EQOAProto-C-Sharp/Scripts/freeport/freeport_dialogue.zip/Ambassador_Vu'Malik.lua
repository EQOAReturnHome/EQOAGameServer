function event_say()
diagOptions = {}
    npcDialogue = "Leave me be, cretin!"
SendDialogue(mySession, npcDialogue, diagOptions)
end