function event_say()
diagOptions = {}
    npcDialogue = "I ain't listenin'!"
SendDialogue(mySession, npcDialogue, diagOptions)
end