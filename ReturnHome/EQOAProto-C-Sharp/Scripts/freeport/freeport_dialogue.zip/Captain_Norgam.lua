function event_say()
diagOptions = {}
    npcDialogue = "Even in the darkest hours of life, this city shall prevail.  I will see to that with my life."
SendDialogue(mySession, npcDialogue, diagOptions)
end