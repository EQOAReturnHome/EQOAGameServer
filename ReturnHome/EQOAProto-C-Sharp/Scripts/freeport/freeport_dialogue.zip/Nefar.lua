function event_say()
diagOptions = {}
    npcDialogue = "Greetings, playerName. Safe travels to you."
SendDialogue(mySession, npcDialogue, diagOptions)
end