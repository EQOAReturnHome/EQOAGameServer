function event_say()
diagOptions = {}
    npcDialogue = "Get out of my way!!"
SendDialogue(mySession, npcDialogue, diagOptions)
end