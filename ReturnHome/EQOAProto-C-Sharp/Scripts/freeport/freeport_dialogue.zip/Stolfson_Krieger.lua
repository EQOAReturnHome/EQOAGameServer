function event_say()
diagOptions = {}
    npcDialogue = "Quit pestering me.  I have serious work to be doing."
SendDialogue(mySession, npcDialogue, diagOptions)
end