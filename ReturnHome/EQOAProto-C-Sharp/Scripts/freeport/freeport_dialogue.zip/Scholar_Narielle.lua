function event_say()
diagOptions = {}
    npcDialogue = "So many tomes to scry, so little time. I wish I had time to read every book in Norrath."
SendDialogue(mySession, npcDialogue, diagOptions)
end