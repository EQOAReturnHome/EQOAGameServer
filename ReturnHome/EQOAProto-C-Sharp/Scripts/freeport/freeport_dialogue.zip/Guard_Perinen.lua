function event_say()
diagOptions = {}
    npcDialogue = "Keep out of trouble and you'll keep out of a burial."
SendDialogue(mySession, npcDialogue, diagOptions)
end