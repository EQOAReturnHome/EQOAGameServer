function event_say()
diagOptions = {}
    npcDialogue = "I'm really busy right now playerName, could you please come back later?"
SendDialogue(mySession, npcDialogue, diagOptions)
end