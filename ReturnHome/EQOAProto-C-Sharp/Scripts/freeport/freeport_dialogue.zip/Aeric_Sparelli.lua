function event_say()
diagOptions = {}
    npcDialogue = "Out of my way, fool.  I have things to do, and I can't have a simple minded fool like you distracting me."
SendDialogue(mySession, npcDialogue, diagOptions)
end