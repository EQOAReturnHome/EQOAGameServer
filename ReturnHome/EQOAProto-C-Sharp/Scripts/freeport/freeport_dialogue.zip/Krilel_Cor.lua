function event_say()
diagOptions = {}
    npcDialogue = "As long as I live, no one will harm the people of this city!"
SendDialogue(mySession, npcDialogue, diagOptions)
end