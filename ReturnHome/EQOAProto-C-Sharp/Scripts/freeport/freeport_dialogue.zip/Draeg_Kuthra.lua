function event_say()
diagOptions = {}
    npcDialogue = "Leave me in piece, would ya?  I've come to drink me drink and mind me own.  Run along now."
SendDialogue(mySession, npcDialogue, diagOptions)
end