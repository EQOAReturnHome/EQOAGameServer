function event_say()
diagOptions = {}
    npcDialogue = "Keep your eyes peeled.  Some shifty characters occupy this city playerName.  Keep your pocket tight."
SendDialogue(mySession, npcDialogue, diagOptions)
end