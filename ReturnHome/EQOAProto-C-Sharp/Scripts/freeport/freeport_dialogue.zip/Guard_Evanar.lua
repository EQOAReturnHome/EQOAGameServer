function event_say()
diagOptions = {}
    npcDialogue = "Keep your eyes peeled.  Some shifty characters occupy this city. Keep your pocket tight."
SendDialogue(mySession, npcDialogue, diagOptions)
end