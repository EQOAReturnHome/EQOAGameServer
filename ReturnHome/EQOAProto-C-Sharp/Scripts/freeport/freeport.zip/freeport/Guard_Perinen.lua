function event_say()
    npcDialogue = "Keep out of trouble and you'll keep out of a burial."
end
