function event_say()
    npcDialogue = "We will protect this city with our lives if it's the last thing we do."
end
