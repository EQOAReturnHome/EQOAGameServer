function event_say()
    npcDialogue = "I haven't the time to be wasted.  Out of my way, peasant!"
end
