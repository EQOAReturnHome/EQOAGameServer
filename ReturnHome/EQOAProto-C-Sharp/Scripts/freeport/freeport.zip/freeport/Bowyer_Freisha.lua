function event_say()
    npcDialogue = "Fancy yourself a bow and arrow?"
end
