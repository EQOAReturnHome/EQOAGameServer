function event_say()
    npcDialogue = "Though alchemy is a much needed profession, it is much too dangerous for most. I've seen too many pupils hurt themselves over careless mistakes!"
end
