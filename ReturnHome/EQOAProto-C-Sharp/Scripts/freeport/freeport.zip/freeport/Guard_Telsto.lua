function event_say()
    npcDialogue = "Abide by the law, and your corpse won't be thrown from my blade."
end
