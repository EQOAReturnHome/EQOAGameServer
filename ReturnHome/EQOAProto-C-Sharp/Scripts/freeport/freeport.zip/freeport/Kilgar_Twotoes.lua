function event_say()
    npcDialogue = "Perhaps there is something I can assist you with?"
end
