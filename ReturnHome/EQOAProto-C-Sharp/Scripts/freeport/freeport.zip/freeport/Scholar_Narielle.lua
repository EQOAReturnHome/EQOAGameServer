function event_say()
    npcDialogue = "So many tomes to scry, so little time.  I wish I had time to read every book in Norrath."
end
