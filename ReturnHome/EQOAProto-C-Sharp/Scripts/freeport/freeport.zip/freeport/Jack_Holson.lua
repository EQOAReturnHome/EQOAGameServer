function event_say()
    npcDialogue = "We sell drink and food.  What can I get for you?"
end
