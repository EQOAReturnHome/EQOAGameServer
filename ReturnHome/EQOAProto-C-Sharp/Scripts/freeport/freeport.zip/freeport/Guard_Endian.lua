function event_say()
    npcDialogue = "You may enter Freeport's only guild for all users of the arcane arts.  I shall hope you won't cause any issues."
end
