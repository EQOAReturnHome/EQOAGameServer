function event_say()
    npcDialogue = "What do you want with me?"
end
