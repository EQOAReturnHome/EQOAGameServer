function event_say()
    npcDialogue = "I don't know you, and I don't care to."
end
