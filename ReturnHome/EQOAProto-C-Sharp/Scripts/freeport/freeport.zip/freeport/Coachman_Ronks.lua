function event_say()
    npcDialogue = "Where would you like to go?"
end
