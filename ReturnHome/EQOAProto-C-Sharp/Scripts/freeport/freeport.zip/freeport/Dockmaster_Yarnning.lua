function event_say()
    npcDialogue = "I can set you up for a one way trip to Arcadin if you'd like."
end
