function event_say()
    npcDialogue = "Music isn't just a profession, It's a way of life. It is it's own art, magic and enchantment that we all can understand. Think about it. It is always there surrounding you, wherever you go."
end
