function event_say()
    npcDialogue = "There's much to be done, and so little time to do it.  You should be on your way."
end
