function event_say()
    npcDialogue = "I am quite busy with my students right now. Are you sure you're in the right place?"
end
