function event_say()
    npcDialogue = "Out of my way, fool.  I have things to do, and I can't have a simple minded fool like you distracting me."
end
