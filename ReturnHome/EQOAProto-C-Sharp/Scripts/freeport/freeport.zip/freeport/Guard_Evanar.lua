function event_say()
    npcDialogue = "Keep your eyes peeled.  Some shifty characters occupy this city.  Keep your pocket tight."
end
