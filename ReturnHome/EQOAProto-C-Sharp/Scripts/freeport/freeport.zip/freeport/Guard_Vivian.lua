function event_say()
    npcDialogue = "I'm watching these dunes.  No deathfist will get past my eyes."
end
