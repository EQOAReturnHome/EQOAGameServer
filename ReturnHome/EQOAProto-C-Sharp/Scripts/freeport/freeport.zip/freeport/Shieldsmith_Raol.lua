function event_say()
    npcDialogue = "Being the only shieldsmith in Freeport, I take much pride in my craft.  Have a look for yourself."
end
