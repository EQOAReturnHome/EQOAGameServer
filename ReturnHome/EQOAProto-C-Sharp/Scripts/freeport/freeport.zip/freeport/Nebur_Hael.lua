function event_say()
    npcDialogue = "I have nothing to say to ye."
end
