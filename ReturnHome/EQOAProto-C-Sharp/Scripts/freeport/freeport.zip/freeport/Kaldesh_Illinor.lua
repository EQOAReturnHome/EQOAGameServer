function event_say()
    npcDialogue = "Can a man not have his drink in peace?  Please leave me be."
end
