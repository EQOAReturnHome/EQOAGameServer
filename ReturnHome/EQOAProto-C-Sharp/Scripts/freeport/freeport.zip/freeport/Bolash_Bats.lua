function event_say()
    npcDialogue = " "
end
function event_say()
    npcDialogue = " "
end
