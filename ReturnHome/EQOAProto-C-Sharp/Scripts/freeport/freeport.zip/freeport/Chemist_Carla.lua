function event_say()
    npcDialogue = "Are you interested in buying some Alchemist scrolls?"
end
