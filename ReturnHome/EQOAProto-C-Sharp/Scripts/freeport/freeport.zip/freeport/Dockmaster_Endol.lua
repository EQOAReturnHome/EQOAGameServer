function event_say()
    npcDialogue = "I love listening to the waves crash.  I couldn't tell you of a more peaceful existence."
end
