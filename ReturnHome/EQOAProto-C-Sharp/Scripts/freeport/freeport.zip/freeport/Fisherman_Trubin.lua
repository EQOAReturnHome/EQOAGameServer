function event_say()
    npcDialogue = "The sea breeze is one of the most soothing things about this world.  Sitting out here all day catching fish is one amazing way to pass the time.  Are you interested in learning how to fish?"
end
