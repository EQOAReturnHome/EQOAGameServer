function event_say()
    npcDialogue = "Looking to add a little flight to your arsenal?"
end
