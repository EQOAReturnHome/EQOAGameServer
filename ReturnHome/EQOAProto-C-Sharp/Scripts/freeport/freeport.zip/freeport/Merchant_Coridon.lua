function event_say()
    npcDialogue = "Would you be interested in buying some Magician spells?"
end
