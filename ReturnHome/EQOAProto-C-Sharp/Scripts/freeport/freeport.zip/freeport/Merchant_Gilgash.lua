function event_say()
    npcDialogue = "What can I get for you?"
end
