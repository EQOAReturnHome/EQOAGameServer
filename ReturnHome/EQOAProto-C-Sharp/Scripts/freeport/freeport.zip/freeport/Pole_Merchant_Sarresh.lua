function event_say()
    npcDialogue = "Looking for a pole to fish with?"
end
