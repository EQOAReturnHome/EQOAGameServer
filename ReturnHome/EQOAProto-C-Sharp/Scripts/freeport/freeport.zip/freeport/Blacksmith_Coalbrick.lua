function event_say()
    npcDialogue = "Confused to see a Barbarian all the way in the desert?  The commander heard of my skills and sent word all the way to Halas requesting I come and forge armor for the guardsmen here.  Are you interested in learning Armor smithing??"
end
