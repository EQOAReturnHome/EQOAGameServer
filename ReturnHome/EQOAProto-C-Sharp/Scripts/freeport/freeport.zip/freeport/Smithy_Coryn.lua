function event_say()
    npcDialogue = "Looking for some armor?"
end
