function event_say()
    npcDialogue = "Continue North to find the Bazaar.  There you will find all of our merchants of trade, as well as our bankers!"
end
