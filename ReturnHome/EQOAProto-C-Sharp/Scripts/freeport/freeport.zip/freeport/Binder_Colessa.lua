function event_say()
    npcDialogue = "What brings you 'round these parts?"
end
