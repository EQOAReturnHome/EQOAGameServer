function event_say()
    npcDialogue = "A pleasure to see you, Darling.  I wish I could stay and chat but time is of the essence."
end
