function event_say()
    npcDialogue = "Have you come to learn the trade of song, traveler?  No?  Well, please be on your way then."
end
