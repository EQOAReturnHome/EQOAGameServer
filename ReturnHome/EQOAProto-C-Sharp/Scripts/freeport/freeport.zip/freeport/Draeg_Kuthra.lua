function event_say()
    npcDialogue = "Leave me in piece, would ya?  I've come to drink me drink and mind me own.  Run along now."
end
