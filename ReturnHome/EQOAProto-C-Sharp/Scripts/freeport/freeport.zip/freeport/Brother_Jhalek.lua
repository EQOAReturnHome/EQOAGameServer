function event_say()
    npcDialogue = "If you have nothing to say then please be on your way."
end
