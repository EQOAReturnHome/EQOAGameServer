function event_say()
    npcDialogue = "Let this diverse land be invaded.  Our enemies shall know pain by the edge of my blade."
end
