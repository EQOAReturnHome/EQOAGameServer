function event_say()
    npcDialogue = "I see you have an interest in jewelry.  Care to learn a few things about Jewel crafting?"
end
