function event_say()
    npcDialogue = "I'm sorry.  Is there a reason you are bother me?  Leave at once."
end
