function event_say()
    npcDialogue = "*hic* You know, I.. I'd love to get.. *hic* a job but.. I.. *hic* am so preoccupied."
end
