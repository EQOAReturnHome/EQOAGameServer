function event_say()
    npcDialogue = "Interested in some of my finer works?"
end
