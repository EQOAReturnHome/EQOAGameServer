function event_say()
    npcDialogue = "Greetings, friend!  If you haven't any business with me then please be on your way."
end
