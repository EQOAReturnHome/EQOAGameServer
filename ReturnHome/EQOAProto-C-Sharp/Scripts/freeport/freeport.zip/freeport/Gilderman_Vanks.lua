function event_say()
    npcDialogue = "Alchemy is often quite misunderstood. Most pupils take quite a long time to master the minutiae of potion design. Only the most dedicated will arrive at our more celebrated and prestigious ranks."
end
