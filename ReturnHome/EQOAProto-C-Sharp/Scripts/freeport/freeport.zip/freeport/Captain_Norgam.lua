function event_say()
    npcDialogue = "Even in the darkest hours of life, this city shall prevail.  I will see to that with my life."
end
