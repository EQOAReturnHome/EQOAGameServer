function event_say()
    npcDialogue = "Countless times, I have watched the sun set on this town, and I often wonder.. when will be my final sunset?"
end
