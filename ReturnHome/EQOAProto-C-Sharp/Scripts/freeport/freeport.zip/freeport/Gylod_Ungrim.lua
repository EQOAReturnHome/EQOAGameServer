function event_say()
    npcDialogue = "Directly south of here lies, Muniel's Tea Garden.  You can reach it by following the road directly behind me."
end
