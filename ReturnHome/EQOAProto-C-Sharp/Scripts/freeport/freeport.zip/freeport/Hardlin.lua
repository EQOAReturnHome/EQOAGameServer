function event_say()
    npcDialogue = "Greetings, adventurer!  I hope you find everything here easily."
end
