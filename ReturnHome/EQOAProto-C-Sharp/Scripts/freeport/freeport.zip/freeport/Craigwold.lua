function event_say()
    npcDialogue = "Freeport is an interesting city, an interesting city indeed.  I'm sorry, I was lost in thought, was there something you needed of me?"
end
