function event_say()
    npcDialogue = "Come here to pick up a sword, 'ave ya?  Or are ya just passin' through?"
end
