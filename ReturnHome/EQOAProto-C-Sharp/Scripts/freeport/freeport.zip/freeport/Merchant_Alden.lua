function event_say()
    npcDialogue = "Would you be interested in buying some Wizard spells?"
end
