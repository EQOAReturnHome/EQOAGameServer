function event_say()
    npcDialogue = "Yes, the darkness touches the dagger and sword evenly.  And only those truly embraced by the darkness shall know the truth behind life."
end
