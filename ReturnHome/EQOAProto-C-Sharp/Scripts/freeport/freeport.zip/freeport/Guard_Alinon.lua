function event_say()
    npcDialogue = "That Hujind is such a coward.  Hasn't see an ounce of blood shed.  If you see anything amiss, report it to me and not that fool."
end
