function event_say()
    npcDialogue = "Welcome to the Bank of Freeport!  Are you here to make a withdrawal or a deposit?"
end
