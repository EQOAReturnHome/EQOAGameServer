function event_say()
    npcDialogue = "I ain't listenin'!"
end
