function event_say()
    npcDialogue = "Oi!  'ave I got som'hin fer you!!"
end
