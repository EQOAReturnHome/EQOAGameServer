function event_say()
    npcDialogue = "The iron and forge are two pieces of the same entity.  Do you want to learn the ways of Weaponsmithing?"
end
