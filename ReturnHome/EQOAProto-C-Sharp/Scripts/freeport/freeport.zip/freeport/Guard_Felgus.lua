function event_say()
    npcDialogue = "I'd be happy to show you around if only I were off duty.  Safe travels!"
end
