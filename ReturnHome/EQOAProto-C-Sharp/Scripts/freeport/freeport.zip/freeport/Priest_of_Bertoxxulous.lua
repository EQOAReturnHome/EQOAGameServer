function event_say()
    npcDialogue = "Ahh, yes child.  You come to me seeking wisdom, yet there is nothing for me to teach you.  Go into the ways of the darkness and all shall be revealed."
end
