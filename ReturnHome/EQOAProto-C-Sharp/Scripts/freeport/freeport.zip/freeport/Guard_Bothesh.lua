function event_say()
    npcDialogue = "Good tidings, citizen."
end
