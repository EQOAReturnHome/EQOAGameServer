function event_say()
    npcDialogue = "What can I offer you?"
end
