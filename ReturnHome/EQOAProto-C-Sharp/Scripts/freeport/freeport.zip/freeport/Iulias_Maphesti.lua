function event_say()
    npcDialogue = "I run this place these days, but not a day goes by that I don't wish I were still an adventurer like yourself."
end
