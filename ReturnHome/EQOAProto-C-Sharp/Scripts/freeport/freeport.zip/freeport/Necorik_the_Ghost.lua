function event_say()
    npcDialogue = "Out of my sight worm, I have no use for you."
end
