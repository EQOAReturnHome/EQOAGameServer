function event_say()
    npcDialogue = "Away with you!  I will turn your corpse into a mound of bone and flesh!"
end
