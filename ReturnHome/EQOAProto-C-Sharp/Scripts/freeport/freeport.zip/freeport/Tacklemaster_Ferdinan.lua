function event_say()
    npcDialogue = "Interested in buying some bait for your line?"
end
