function event_say()
    npcDialogue = "Greetings, child.  Perhaps one day, You can help me with some research.  If I ever need you, I will send for you."
end
