function event_say()
    npcDialogue = "I'm watching you."
end
