function event_say()
    npcDialogue = "Excuse me, but I need some space to read.  If I need anything from you, I'll send for you.  Until then, farewell."
end
