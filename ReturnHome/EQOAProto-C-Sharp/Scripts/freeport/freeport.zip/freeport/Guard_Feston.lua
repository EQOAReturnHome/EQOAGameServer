function event_say()
    npcDialogue = "Whaddaya want??  Can't ya see I'm on duty?"
end
