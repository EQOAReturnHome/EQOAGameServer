function event_say()
    npcDialogue = "What can I do you for??"
end
