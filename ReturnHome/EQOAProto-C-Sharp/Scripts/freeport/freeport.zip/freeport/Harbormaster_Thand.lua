function event_say()
    npcDialogue = "I've got some poles and bait to sell to you!!  Speak with Yarnning about if you'd like to catch a ship somewhere!!"
end
