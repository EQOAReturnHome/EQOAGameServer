function event_say()
    npcDialogue = "I'm sorry but I'm extremely busy. I wish I had more time to offer you.  Safe travels to you, dear."
end
