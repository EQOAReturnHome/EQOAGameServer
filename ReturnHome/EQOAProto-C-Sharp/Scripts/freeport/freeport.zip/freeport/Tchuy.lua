function event_say()
    npcDialogue = "Drink guud!!  Tchuy always come here for guud drink."
end
