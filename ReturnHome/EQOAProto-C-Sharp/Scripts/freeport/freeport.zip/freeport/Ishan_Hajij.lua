function event_say()
    npcDialogue = "Greetings, traveler!  Have you come seeking knowledge in the arcane arts?"
end
