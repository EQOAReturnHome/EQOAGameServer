function event_say()
    npcDialogue = "You should spend your time reading, and gaining knowledge. Nothing bothering me."
end
