function event_say()
    npcDialogue = "Away with you, vermin."
end
