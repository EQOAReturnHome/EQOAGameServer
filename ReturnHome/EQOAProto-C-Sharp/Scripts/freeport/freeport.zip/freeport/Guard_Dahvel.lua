function event_say()
    npcDialogue = "As you were, citizen."
end
