function event_say()
    npcDialogue = "I've got my eye on you."
end
