function event_say()
    npcDialogue = "Can I interest you in some of my wares?"
end
