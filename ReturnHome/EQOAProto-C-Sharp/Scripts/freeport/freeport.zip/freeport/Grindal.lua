function event_say()
    npcDialogue = "What's that??  Sorry, I don't know you."
end
