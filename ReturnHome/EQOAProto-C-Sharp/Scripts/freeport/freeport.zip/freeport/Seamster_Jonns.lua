function event_say()
    npcDialogue = "Thread working takes a steady hand and a skill eye.  Are you interested in learning tailoring?"
end
