function event_say()
    npcDialogue = "Whaddaya' want??"
end
