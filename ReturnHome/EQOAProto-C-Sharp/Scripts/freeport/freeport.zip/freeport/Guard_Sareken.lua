function event_say()
    npcDialogue = "No one realizes how difficult this job actually is. It's blazing hot, criminals are everywhere, and we don't even have all the supplies to do our job. Somedays, I think about changing to a simpler life."
end
