function event_say()
    npcDialogue = "You'll have to forgive my brother, he can very uptight sometimes.  Don't take anything he says to heart."
end
