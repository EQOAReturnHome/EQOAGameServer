function event_say()
    npcDialogue = "Looking to purchase some molds?"
end
