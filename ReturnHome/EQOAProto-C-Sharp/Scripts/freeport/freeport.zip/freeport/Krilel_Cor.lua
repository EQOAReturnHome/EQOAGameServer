function event_say()
    npcDialogue = "As long as I live, no one will harm the people of this city!"
end
