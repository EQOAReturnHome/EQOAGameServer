function event_say()
    npcDialogue = "Greetings, friend.  Safe travels to you."
end
