function event_say()
    npcDialogue = "The darkness will overtake us all.  Only in the absence of light will the truth be revealed and the true power of light can emerge."
end
