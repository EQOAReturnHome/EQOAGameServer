function event_say()
    npcDialogue = "Is there something I can help you with?"
end
