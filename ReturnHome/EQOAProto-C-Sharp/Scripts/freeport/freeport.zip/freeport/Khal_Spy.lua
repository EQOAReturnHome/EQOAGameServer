function event_say()
    npcDialogue = "Away with you, You'll have me spotted, fool."
end
