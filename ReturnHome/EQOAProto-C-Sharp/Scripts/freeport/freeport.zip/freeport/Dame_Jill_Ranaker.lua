function event_say()
    npcDialogue = "I'm sorry but you'll have to excuse me.  I'm extremely busy."
end
