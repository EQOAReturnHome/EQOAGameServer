function event_say()
    npcDialogue = "What can I help you with?"
end
