function event_say()
    npcDialogue = "Pardon me, but I am busy at the moment.  Away with you."
end
