function event_say()
    npcDialogue = "I don't have time for idle chatter.  Please be on your way."
end
