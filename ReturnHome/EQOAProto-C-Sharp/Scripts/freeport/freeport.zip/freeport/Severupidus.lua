function event_say()
    npcDialogue = "Quit pestering me.  I have serious work to be doing."
end
