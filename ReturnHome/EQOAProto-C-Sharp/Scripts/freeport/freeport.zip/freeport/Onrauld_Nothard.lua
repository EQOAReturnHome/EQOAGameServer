function event_say()
    npcDialogue = "Get out of my sight."
end
