function event_say()
    npcDialogue = "Get away from me before my blade leaves you eviscerated!"
end
