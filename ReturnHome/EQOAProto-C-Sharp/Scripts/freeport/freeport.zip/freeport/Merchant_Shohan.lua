function event_say()
    npcDialogue = "Looking to buy some ores?"
end
