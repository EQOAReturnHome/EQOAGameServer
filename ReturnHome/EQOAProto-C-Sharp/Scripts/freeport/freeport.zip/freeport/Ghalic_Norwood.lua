function event_say()
    npcDialogue = "Oh!!  A customer!!  How may I help you?"
end
