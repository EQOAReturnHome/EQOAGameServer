function event_say()
    npcDialogue = "NEXT!!!!!!"
end
