function event_say()
    npcDialogue = "Can't you see I'm working here?  If the commander see's me chatting, he'll have me stripped of my position.  Away with you!"
end
