function event_say()
    npcDialogue = "Oi!!  You 'aven't got a few tunar to spare so an old man can get a wee' bit o' mead in 'is belly, do ye?"
end
