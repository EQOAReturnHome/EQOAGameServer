function event_say()
    npcDialogue = "I'm really busy right now, could you please come back later?"
end
