function event_say()
    npcDialogue = "What do you want?!  Get out of here."
end
