function event_say()
    npcDialogue = "Our enemies could strike any day.  I gave oath to this city to uphold our peaceful liberties, and I shall train my warriors day in and day out to insure those liberties stay intact."
end
