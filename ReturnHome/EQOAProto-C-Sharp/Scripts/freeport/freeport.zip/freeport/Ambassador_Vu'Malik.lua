function event_say()
    npcDialogue = "Leave me be, cretin!"
end
