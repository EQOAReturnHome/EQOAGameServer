function event_say()
    npcDialogue = "I have traveled many moons in search of the legend known as Xylof.  Yet, in all of my time spent, I have yet to find him."
end
