function event_say()
    npcDialogue = "Can I help you to anything?"
end
