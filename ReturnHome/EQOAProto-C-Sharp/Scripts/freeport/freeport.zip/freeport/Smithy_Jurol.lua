function event_say()
    npcDialogue = "Looking for some weapons?"
end
