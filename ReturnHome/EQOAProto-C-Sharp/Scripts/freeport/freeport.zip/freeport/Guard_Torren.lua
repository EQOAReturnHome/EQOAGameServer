function event_say()
    npcDialogue = "I'm on duty.  Shove off."
end
