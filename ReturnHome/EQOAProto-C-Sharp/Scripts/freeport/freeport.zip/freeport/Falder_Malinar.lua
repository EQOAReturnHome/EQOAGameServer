function event_say()
    npcDialogue = "Have you been to the docks, yet?  'tis a beautiful sight, you cannot miss it!"
end
