function event_say()
    npcDialogue = "If you weren't sent to me, then you will leave at once or I will call the guards to have you removed."
end
