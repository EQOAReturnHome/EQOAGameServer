function event_say()
    npcDialogue = "Hail traveler!"
end
