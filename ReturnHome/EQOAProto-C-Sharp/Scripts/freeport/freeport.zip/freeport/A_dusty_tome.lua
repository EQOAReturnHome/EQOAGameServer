function event_say()
    npcDialogue = " "
end
