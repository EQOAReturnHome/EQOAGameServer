function event_say()
    npcDialogue = "Where would you like for me to send you?"
end
