function event_say()
    npcDialogue = "Welcome to our little tavern, adventurer.  I hope you find everything here well!"
end
