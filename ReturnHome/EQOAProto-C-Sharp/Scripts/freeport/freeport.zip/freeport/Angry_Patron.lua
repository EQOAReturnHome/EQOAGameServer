function event_say()
    npcDialogue = "Get out of my way!!"
end
