function event_say()
    npcDialogue = "Would you like me to bind your spirit to this location, child?"
end
